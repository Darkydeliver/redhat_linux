#!/bin/bash

# Define the output folder and files created by the main script
output_folder="./Linux_output/Discovery"
output_file="$output_folder/discovery_output.txt"

# Function to remove output files and folders
cleanup_files() {
    echo "Cleaning up output files and directories..."
    # Remove the discovery output file if it exists
    if [ -f "$output_file" ]; then
        rm -f "$output_file" && echo "Removed: $output_file"
    else
        echo "No output file found to remove."
    fi

    # Remove the output folder if it's empty
    if [ -d "$output_folder" ] && [ -z "$(ls -A "$output_folder")" ]; then
        rmdir "$output_folder" && echo "Removed empty directory: $output_folder"
    else
        echo "Directory $output_folder is not empty or does not exist."
    fi
}

# Main cleanup function
main_cleanup() {
    cleanup_files
    echo "Cleanup completed."
}

# Run the main cleanup function
main_cleanup
