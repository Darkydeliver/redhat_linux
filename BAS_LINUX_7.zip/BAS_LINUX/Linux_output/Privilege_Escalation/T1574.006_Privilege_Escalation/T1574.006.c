#include <stdio.h>
#include <stdlib.h>

void init() __attribute__((constructor));

void init() {
    printf("Shared library injected via LD_PRELOAD or /etc/ld.so.preload\n");
    // Add your malicious code or functionality here
}
