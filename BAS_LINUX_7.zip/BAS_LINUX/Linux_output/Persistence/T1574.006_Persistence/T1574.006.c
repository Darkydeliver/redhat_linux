#include <stdio.h>
#include <stdlib.h>

void init() __attribute__((constructor));

void init() {
    printf("Shared library injected for persistence via LD_PRELOAD or /etc/ld.so.preload\n");
    // Add your persistence code or functionality here
}
