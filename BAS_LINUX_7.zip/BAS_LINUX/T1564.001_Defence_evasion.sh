#!/bin/bash

# T1564.001 - Hide Artifacts: Hidden Files and Directories

# Function to create a hidden directory and hidden file
create_hidden_artifacts() {
  echo "Creating a hidden directory and hidden file..."
  mkdir -p /var/tmp/.hidden-directory
  echo "T1564.001" > /var/tmp/.hidden-directory/.hidden-file
  echo "Hidden directory and file created."
}

# Function to verify the creation of hidden artifacts
verify_hidden_artifacts() {
  echo "Verifying hidden artifacts..."
  if [ -d /var/tmp/.hidden-directory ] && [ -f /var/tmp/.hidden-directory/.hidden-file ]; then
    echo "Hidden directory and file exist."
  else
    echo "Hidden directory and file do not exist."
  fi
}

# Function to clean up the hidden directory and hidden file
cleanup_hidden_artifacts() {
  echo "Cleaning up hidden artifacts..."
  rm -rf /var/tmp/.hidden-directory/
  echo "Hidden artifacts cleaned up."
}

# Main script execution
echo "Running T1564.001 - Hide Artifacts: Hidden Files and Directories"
create_hidden_artifacts
verify_hidden_artifacts
cleanup_hidden_artifacts
echo "SISA Test - T1564.001 completed."
