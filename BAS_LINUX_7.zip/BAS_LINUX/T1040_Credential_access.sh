#!/bin/bash

# Function to install packages if not already installed
install_packages() {
    if which yum &> /dev/null; then
        yum -y install epel-release tcpdump tshark
    elif which apt-get &> /dev/null; then
        DEBIAN_FRONTEND=noninteractive apt-get -y install tcpdump tshark
    else
        echo "Unsupported package manager. Please install required packages manually."
        exit 1
    fi
}

# Function to identify active network interface
identify_interface() {
    local interface
    # Using 'ip route' to find the default route and extracting the interface
    interface=$(ip route get 1 | grep -oP 'dev\s+\K\S+')
    if [[ -z "$interface" ]]; then
        echo "Failed to identify active network interface."
        exit 1
    fi
    echo "$interface"
}

# Main script
# Define the output directory and file
output_dir="Linux_output/Credential_access"
mkdir -p "$output_dir"
output_file="${output_dir}/T1040_Credential_access.txt"

# Install packages if not already installed
which tcpdump tshark &> /dev/null || install_packages

# Identify the network interface
interface=$(identify_interface)

if [[ -z "$interface" ]]; then
    echo "Error: No network interface found."
    exit 1
fi

{
    # Capture packets using tcpdump
    echo "Capturing packets using tcpdump on interface: $interface"
    tcpdump -c 5 -nnni "$interface"
    echo "tcpdump capture complete."

    # Capture packets using tshark
    echo "Capturing packets using tshark on interface: $interface"
    tshark -c 5 -i "$interface"
    echo "tshark capture complete."
} | tee "$output_file"

echo "Output saved to ${output_file}"
