#include <stdio.h>

int main() {
    printf("Hello from cap.c program.\n");
    return 0;
}
