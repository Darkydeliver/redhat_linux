#!/bin/bash

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install auditd if not installed
install_auditd() {
    if ! command_exists auditctl; then
        echo "auditd is not installed. Installing auditd..."
        if command_exists apt-get; then
            sudo apt-get update && sudo apt-get install auditd -y
        elif command_exists yum; then
            sudo yum install audit -y
        elif command_exists dnf; then
            sudo dnf install audit -y
        else
            echo "Cannot install auditd. Package manager not found."
            exit 1
        fi
    fi
}

# Function to check if auditd is running
check_auditd_running() {
    if ! pgrep -x "auditd" >/dev/null; then
        echo "auditd is not running. Starting auditd..."
        sudo service auditd start
    fi
}

# Function for cleanup actions
cleanup() {
    case "$1" in
        "audit_rules")
            echo "Cleanup: Restoring auditd rules..."
            sudo service auditd restart
            echo "Restored auditd rules."
            ;;
        "audit_disable")
            echo "Cleanup: Re-enabling auditd..."
            sudo auditctl -e 1
            echo "Re-enabled auditd."
            ;;
        *)
            echo "No cleanup actions specified."
            ;;
    esac
}

# SISA Test #1: Delete all auditd rules using auditctl
sisa_test_1() {
    echo "Executing SISA Test #1: Delete all auditd rules using auditctl..."
    sudo auditctl -D
    if [ $? -eq 0 ]; then
        echo "Deleted all auditd rules."
        cleanup "audit_rules"
        echo "SISA Test #1 executed successfully."
    else
        echo "Failed to delete auditd rules. Check logs for details."
        exit 1
    fi
}

# SISA Test #2: Disable auditd using auditctl
sisa_test_2() {
    echo "Executing SISA Test #2: Disable auditd using auditctl..."
    sudo auditctl -e 0
    if [ $? -eq 0 ]; then
        echo "Disabled auditd."
        echo "SISA Test #2 executed successfully."
    else
        echo "Failed to disable auditd. Check logs for details."
        exit 1
    fi
}

# Main script execution
{
    # Print command being executed
    echo "\$ bash T1562.012_Defence_evasion.sh"
    echo ""

    # Ensure auditd is installed and running
    install_auditd
    check_auditd_running

    # Execute SISA tests
    sisa_test_1
    sisa_test_2

    # Final check if auditd is enabled
    sudo auditctl -e 1
} > "./Linux_output/Defence_Evasion/T1562.012_Defence_evasion.txt" 2>&1  # Redirect both stdout and stderr to the output file
echo "Execution of T1562.102 completed"
echo "Output saved to: Linux_output/Defence_Evasion/T1562.012_Defence_evasion.txt"
