#!/bin/bash

# Function to install Golang if not present
install_go() {
    echo "Installing Golang..."
    sudo apt update
    sudo apt install golang -y
}

# Function to check if Go is installed
check_go_installation() {
    if ! command -v go &> /dev/null; then
        echo "Golang could not be found"
        install_go
    else
        echo "Golang is already installed"
    fi
}

# Check and install Go
check_go_installation

# Directories
src_dir="/tmp/sisa_tests/T1027.004/src"
output_dir="./Linux_output/Defence_Evasion"
output_file="$output_dir/T1027.004_output.txt"

# Ensure the output directory exists
mkdir -p "$src_dir"
mkdir -p "$output_dir"

# Redirect all output to the output file
exec > >(tee -a "$output_file") 2>&1

# SISA Test #1 - C compile
c_file="$src_dir/T1027-004-test.c"
wget -O "$c_file" "https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1027.004/src/T1027-004-test.c"

if [ -e "$c_file" ]; then
    echo "C source file downloaded successfully."
else
    echo "Failed to download C source file."
    exit 1
fi

# Compile and run the C source file
gcc "$c_file" -o "$src_dir/test_c"
if [ -e "$src_dir/test_c" ]; then
    echo "C file compiled successfully."
    "$src_dir/test_c"
else
    echo "Failed to compile C file."
    exit 1
fi

# SISA Test #2 - CC compile
cc_file="$src_dir/T1027-004-test.cc"
wget -O "$cc_file" "https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1027.004/src/T1027-004-test.cc"

if [ -e "$cc_file" ]; then
    echo "C++ source file downloaded successfully."
else
    echo "Failed to download C++ source file."
    exit 1
fi

# Compile and run the C++ source file
g++ "$cc_file" -o "$src_dir/test_cc"
if [ -e "$src_dir/test_cc" ]; then
    echo "C++ file compiled successfully."
    "$src_dir/test_cc"
else
    echo "Failed to compile C++ file."
    exit 1
fi

# SISA Test #3 - Go compile
go_file="$src_dir/T1027-004-test.go"
wget -O "$go_file" "https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1027.004/src/T1027-004-test.go"

if [ -e "$go_file" ]; then
    echo "Go source file downloaded successfully."
else
    echo "Failed to download Go source file."
    exit 1
fi

# Run the Go source file
go run "$go_file"
if [ $? -eq 0 ]; then
    echo "Go file executed successfully."
else
    echo "Failed to execute Go file."
    exit 1
fi

echo "All tests completed."

# Display executed and completed messages in the terminal
echo "Tests executed and completed. Detailed output is stored in $output_file."
